import { useState } from 'react';
import GameCanvas from '../GameCanvas';
import MobileControls from '../MobileControls';

export default function Game() {
  const [gameState, setGameState] = useState('playing');

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center gap-2 p-4">
      <header className="text-center mb-2">
        <h1
          className="text-primary leading-tight"
          style={{ fontFamily: "'Press Start 2P', monospace", fontSize: 'clamp(10px, 2.5vw, 18px)' }}
        >
          🌾 Agrinho
        </h1>
        <p className="text-muted-foreground text-xs mt-1">
          ← → mover &nbsp;|&nbsp; Espaço pular &nbsp;|&nbsp; Z usar poder
        </p>
      </header>

      <GameCanvas onStateChange={setGameState} />

      {/* Controles mobile — só aparece em telas pequenas */}
      <div className="flex md:hidden w-full justify-center">
        <MobileControls />
      </div>
    </div>
  );
}
