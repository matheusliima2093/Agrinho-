import React, { useCallback } from 'react';
import { ArrowLeft, ArrowRight, ArrowUp } from 'lucide-react';

export default function MobileControls({ onInput }) {
  const simulateKey = useCallback((code, down) => {
    const event = new KeyboardEvent(down ? 'keydown' : 'keyup', {
      code,
      bubbles: true,
    });
    window.dispatchEvent(event);
  }, []);

  const handleTouch = (code) => ({
    onTouchStart: (e) => { e.preventDefault(); simulateKey(code, true); },
    onTouchEnd: (e) => { e.preventDefault(); simulateKey(code, false); },
    onMouseDown: () => simulateKey(code, true),
    onMouseUp: () => simulateKey(code, false),
    onMouseLeave: () => simulateKey(code, false),
  });

  return (
    <div className="flex justify-between items-end w-full max-w-[800px] px-4 mt-4 select-none">
      {/* D-pad left/right */}
      <div className="flex gap-3">
        <button
          {...handleTouch('ArrowLeft')}
          className="w-16 h-16 rounded-2xl bg-primary/80 text-primary-foreground flex items-center justify-center active:bg-primary active:scale-95 transition-all shadow-lg touch-none"
        >
          <ArrowLeft className="w-8 h-8" />
        </button>
        <button
          {...handleTouch('ArrowRight')}
          className="w-16 h-16 rounded-2xl bg-primary/80 text-primary-foreground flex items-center justify-center active:bg-primary active:scale-95 transition-all shadow-lg touch-none"
        >
          <ArrowRight className="w-8 h-8" />
        </button>
      </div>

      {/* Right side: Power button + Jump */}
      <div className="flex gap-3 items-end">
        {/* Power / Usar poder agrícola */}
        <button
          {...handleTouch('KeyZ')}
          className="w-14 h-14 rounded-2xl bg-green-700/90 text-white flex flex-col items-center justify-center active:bg-green-600 active:scale-95 transition-all shadow-lg touch-none text-center"
        >
          <span className="text-xl leading-none">🌱</span>
          <span className="text-[9px] font-bold mt-0.5 leading-none">PODER</span>
        </button>

        {/* Jump */}
        <button
          {...handleTouch('Space')}
          className="w-20 h-20 rounded-full bg-secondary text-secondary-foreground flex items-center justify-center active:bg-secondary/80 active:scale-95 transition-all shadow-lg touch-none"
        >
          <ArrowUp className="w-10 h-10" />
        </button>
      </div>
    </div>
  );
}