import {
  TILE_SIZE, GRAVITY, JUMP_FORCE, MOVE_SPEED,
  PLAYER_WIDTH, PLAYER_HEIGHT, TILES, ENTITY_TYPES, POWER_TYPES,
  CANVAS_WIDTH, CANVAS_HEIGHT
} from './constants';
import { levels } from './levels';

export function createGameState(levelIndex = 0) {
  const level = levels[levelIndex];
  if (!level) return null;

  const entities = level.entities.map(e => {
    const isBoss = e.type === ENTITY_TYPES.BOSS;
    const isGoal = e.type === ENTITY_TYPES.GOAL;
    return {
      ...e,
      x: e.x * TILE_SIZE,
      y: e.y * TILE_SIZE,
      width: isBoss ? 64 : isGoal ? 48 : 32,
      height: isBoss ? 64 : isGoal ? TILE_SIZE * 3 : 32,
      active: e.type !== ENTITY_TYPES.HIDDEN_PEST,
      collected: false,
      triggered: false,
      facingRight: false,
      velocityX: e.type === ENTITY_TYPES.PEST_WALK || e.type === ENTITY_TYPES.HIDDEN_PEST ? -(e.speed ?? 1.5) : (isBoss ? -1.2 : 0),
      velocityY: 0,
      startX: e.x * TILE_SIZE,
      startY: e.y * TILE_SIZE,
      triggerX: e.type === ENTITY_TYPES.HIDDEN_PEST ? (e.x - 3) * TILE_SIZE : (isBoss ? (e.x - 10) * TILE_SIZE : 0),
      hp: e.hp ?? 1,
      maxHp: e.hp ?? 1,
      bossType: e.bossType ?? null,
      powerType: e.powerType ?? null,
      speed: e.speed ?? 1.5,
      invincibleTimer: 0,
    };
  });

  return {
    level,
    levelIndex,
    player: {
      x: level.playerStart.x * TILE_SIZE,
      y: level.playerStart.y * TILE_SIZE,
      width: PLAYER_WIDTH,
      height: PLAYER_HEIGHT,
      velocityX: 0,
      velocityY: 0,
      facingRight: true,
      isJumping: false,
      onGround: false,
      isDead: false,
      // Powers
      activePower: null,       // current equipped power type
      powerCooldown: 0,        // frames until can shoot again
      shieldTimer: 0,          // leaf shield frames remaining
      shootPressed: false,     // debounce
    },
    projectiles: [],            // active player projectiles
    entities,
    camera: { x: 0 },
    lives: 5,
    seeds: 0,
    frame: 0,
    state: 'playing', // playing, dead, victory, gameover
    deathMessage: '',
    deathTimer: 0,
    keys: {},
    fakePlatformTimers: {}, // track touched fake platforms
  };
}

export function updateGame(game) {
  if (!game || game.state !== 'playing') return game;

  game.frame++;
  const { player, level, keys, entities } = game;

  // Handle input
  player.velocityX = 0;
  if (keys['ArrowLeft'] || keys['KeyA']) {
    player.velocityX = -MOVE_SPEED;
    player.facingRight = false;
  }
  if (keys['ArrowRight'] || keys['KeyD']) {
    player.velocityX = MOVE_SPEED;
    player.facingRight = true;
  }
  if ((keys['ArrowUp'] || keys['KeyW'] || keys['Space']) && player.onGround) {
    player.velocityY = JUMP_FORCE;
    player.isJumping = true;
    player.onGround = false;
  }

  // Power shoot: Z key or ShiftLeft
  if (keys['KeyZ'] || keys['ShiftLeft']) {
    if (!player.shootPressed && player.activePower && player.powerCooldown <= 0) {
      firePower(game);
      player.shootPressed = true;
    }
  } else {
    player.shootPressed = false;
  }
  if (player.powerCooldown > 0) player.powerCooldown--;
  if (player.shieldTimer > 0) player.shieldTimer--;

  // Apply gravity
  player.velocityY += GRAVITY;
  if (player.velocityY > 15) player.velocityY = 15;

  // Move X
  player.x += player.velocityX;
  resolveCollisionsX(player, level, game);

  // Move Y
  player.y += player.velocityY;
  resolveCollisionsY(player, level, game);

  // Check pit death
  if (player.y > level.height * TILE_SIZE + 100) {
    killPlayer(game, "Caiu no abismo! 🕳️");
  }

  // Clamp to left edge
  if (player.x < 0) player.x = 0;

  // Update camera
  const targetCameraX = player.x - CANVAS_WIDTH / 3;
  game.camera.x += (targetCameraX - game.camera.x) * 0.1;
  if (game.camera.x < 0) game.camera.x = 0;
  const maxCameraX = level.width * TILE_SIZE - CANVAS_WIDTH;
  if (game.camera.x > maxCameraX) game.camera.x = maxCameraX;

  // Update entities
  updateEntities(game);

  // Check entity collisions with player
  checkEntityCollisions(game);

  // Update projectiles
  updateProjectiles(game);

  // Update fake platforms
  updateFakePlatforms(game);

  return game;
}

function getTile(level, tx, ty) {
  if (tx < 0 || tx >= level.width || ty < 0 || ty >= level.height) return TILES.EMPTY;
  return level.tiles[ty]?.[tx] ?? TILES.EMPTY;
}

function isSolid(tileType, game, tx, ty) {
  if (tileType === TILES.GROUND || tileType === TILES.GRASS_TOP ||
      tileType === TILES.BARN_WALL || tileType === TILES.BARN_ROOF || tileType === TILES.INVISIBLE_WALL) {
    return true;
  }
  if (tileType === TILES.PLATFORM || tileType === TILES.FAKE_PLATFORM) {
    const key = `${tx},${ty}`;
    if (tileType === TILES.FAKE_PLATFORM) {
      if (!game.fakePlatformTimers[key]) return true;
      return game.fakePlatformTimers[key] < 15;
    }
    return true;
  }
  return false;
}

// Platforms are one-way: only solid when falling onto them from above
function isPlatformTile(tileType) {
  return tileType === TILES.PLATFORM || tileType === TILES.FAKE_PLATFORM;
}

function resolveCollisionsX(player, level, game) {
  const left = Math.floor(player.x / TILE_SIZE);
  const right = Math.floor((player.x + player.width - 1) / TILE_SIZE);
  const top = Math.floor(player.y / TILE_SIZE);
  const bottom = Math.floor((player.y + player.height - 1) / TILE_SIZE);

  for (let ty = top; ty <= bottom; ty++) {
    for (let tx = left; tx <= right; tx++) {
      const tile = getTile(level, tx, ty);
      // Platforms are one-way — no horizontal blocking
      if (isSolid(tile, game, tx, ty) && !isPlatformTile(tile)) {
        if (player.velocityX > 0) {
          player.x = tx * TILE_SIZE - player.width;
        } else if (player.velocityX < 0) {
          player.x = (tx + 1) * TILE_SIZE;
        }
      }
      if (tile === TILES.SPIKE_UP) {
        killPlayer(game, "Ai! Armadilha espinhosa! 🌵");
      }
    }
  }
}

function resolveCollisionsY(player, level, game) {
  const left = Math.floor(player.x / TILE_SIZE);
  const right = Math.floor((player.x + player.width - 1) / TILE_SIZE);
  const top = Math.floor(player.y / TILE_SIZE);
  const bottom = Math.floor((player.y + player.height - 1) / TILE_SIZE);

  player.onGround = false;

  for (let ty = top; ty <= bottom; ty++) {
    for (let tx = left; tx <= right; tx++) {
      const tile = getTile(level, tx, ty);

      if (tile === TILES.SPIKE_UP) {
        killPlayer(game, "Ai! Armadilha espinhosa! 🌵");
        continue;
      }

      if (!isSolid(tile, game, tx, ty)) continue;

      const isPlat = isPlatformTile(tile);
      const platSurfaceY = ty * TILE_SIZE; // top of tile = landing surface

      if (player.velocityY > 0) {
        // For platforms: only land if player's feet were above the surface last frame
        if (isPlat) {
          const prevFeetY = player.y + player.height - player.velocityY;
          if (prevFeetY > platSurfaceY + 4) continue; // was already below — pass through
        }
        player.y = platSurfaceY - player.height;
        player.velocityY = 0;
        player.onGround = true;
        player.isJumping = false;

        if (tile === TILES.FAKE_PLATFORM) {
          const key = `${tx},${ty}`;
          if (!game.fakePlatformTimers[key]) {
            game.fakePlatformTimers[key] = 1;
          }
        }
      } else if (player.velocityY < 0 && !isPlat) {
        // Only block upward movement for solid ground tiles, not one-way platforms
        player.y = (ty + 1) * TILE_SIZE;
        player.velocityY = 0;
      }
    }
  }
}

function updateFakePlatforms(game) {
  for (const key of Object.keys(game.fakePlatformTimers)) {
    game.fakePlatformTimers[key]++;
    // After a delay, remove the tile visually
    if (game.fakePlatformTimers[key] > 20) {
      const [tx, ty] = key.split(',').map(Number);
      if (game.level.tiles[ty]) {
        game.level.tiles[ty][tx] = TILES.EMPTY;
      }
    }
  }
}

function updateEntities(game) {
  const { entities, player, level } = game;

  entities.forEach(entity => {
    if (entity.collected) return;

    // Hidden pest trigger
    if (entity.type === ENTITY_TYPES.HIDDEN_PEST && !entity.triggered) {
      if (player.x > entity.triggerX) {
        entity.triggered = true;
        entity.active = true;
        const spd = entity.speed ?? 2.5;
        entity.velocityX = player.x > entity.x ? -spd : spd;
      }
      return;
    }

    if (!entity.active) return;

    // Walking pests
    if (entity.type === ENTITY_TYPES.PEST_WALK ||
        (entity.type === ENTITY_TYPES.HIDDEN_PEST && entity.triggered)) {
      // Ensure speed is applied correctly after direction changes
      const spd = entity.speed ?? 1.5;
      entity.velocityX = entity.velocityX >= 0 ? spd : -spd;
      entity.x += entity.velocityX;
      entity.facingRight = entity.velocityX > 0;

      // Apply gravity to walking pests
      entity.velocityY += GRAVITY * 0.5;
      entity.y += entity.velocityY;

      // Ground collision for pest
      const footTileY = Math.floor((entity.y + entity.height) / TILE_SIZE);
      const footTileX = Math.floor((entity.x + entity.width / 2) / TILE_SIZE);
      const belowTile = getTile(level, footTileX, footTileY);
      if (belowTile === TILES.GROUND || belowTile === TILES.GRASS_TOP) {
        entity.y = footTileY * TILE_SIZE - entity.height;
        entity.velocityY = 0;
      }

      // Wall collision - reverse direction
      const frontTileX = entity.velocityX > 0
        ? Math.floor((entity.x + entity.width) / TILE_SIZE)
        : Math.floor(entity.x / TILE_SIZE);
      const midTileY = Math.floor((entity.y + entity.height / 2) / TILE_SIZE);
      const wallTile = getTile(level, frontTileX, midTileY);
      if (wallTile === TILES.GROUND || wallTile === TILES.GRASS_TOP) {
        entity.velocityX *= -1;
      }

      // Edge detection - reverse at platform edges
      const aheadX = entity.velocityX > 0
        ? Math.floor((entity.x + entity.width + 4) / TILE_SIZE)
        : Math.floor((entity.x - 4) / TILE_SIZE);
      const belowAhead = getTile(level, aheadX, footTileY);
      if (belowAhead === TILES.EMPTY && entity.velocityY === 0) {
        entity.velocityX *= -1;
      }

      // Pit death for pest
      if (entity.y > level.height * TILE_SIZE + 100) {
        entity.active = false;
      }
    }

    // Flying pests - sinusoidal movement
    if (entity.type === ENTITY_TYPES.PEST_FLY) {
      entity.x += Math.sin(game.frame * 0.03) * 1.5;
      entity.y = entity.startY + Math.sin(game.frame * 0.04) * 30;
    }

    // Pollution - drifts slowly
    if (entity.type === ENTITY_TYPES.POLLUTION) {
      entity.x = entity.startX + Math.sin(game.frame * 0.02) * 20;
      entity.y = entity.startY + Math.sin(game.frame * 0.03) * 10;
    }

    // Boss movement
    if (entity.type === ENTITY_TYPES.BOSS && entity.active) {
      if (entity.invincibleTimer > 0) entity.invincibleTimer--;

      // Trigger when player is near
      if (!entity.triggered && player.x > entity.triggerX) {
        entity.triggered = true;
      }

      if (entity.triggered) {
        // Chase player horizontally
        const dir = player.x < entity.x ? -1 : 1;
        entity.velocityX = dir * (1.2 + (entity.maxHp - entity.hp) * 0.4);
        entity.facingRight = dir > 0;
        entity.x += entity.velocityX;

        // Bounce vertically
        if (entity.bossType === 'locust') {
          entity.y = entity.startY + Math.sin(game.frame * 0.05) * 50;
        } else if (entity.bossType === 'pollution_boss') {
          entity.y = entity.startY + Math.sin(game.frame * 0.04) * 40;
          entity.x = entity.startX + Math.sin(game.frame * 0.025) * 60;
        } else if (entity.bossType === 'weed_king') {
          // Apply gravity for ground-based boss
          entity.velocityY += GRAVITY * 0.4;
          entity.y += entity.velocityY;
          const footTileY = Math.floor((entity.y + entity.height) / TILE_SIZE);
          const footTileX = Math.floor((entity.x + entity.width / 2) / TILE_SIZE);
          const belowTile = getTile(level, footTileX, footTileY);
          if (belowTile === TILES.GROUND || belowTile === TILES.GRASS_TOP) {
            entity.y = footTileY * TILE_SIZE - entity.height;
            entity.velocityY = 0;
          }
        }

        // Clamp to level bounds
        if (entity.x < 0) { entity.x = 0; entity.velocityX *= -1; }
        if (entity.x > level.width * TILE_SIZE - entity.width) {
          entity.x = level.width * TILE_SIZE - entity.width;
          entity.velocityX *= -1;
        }
      }
    }
  });
}

function checkEntityCollisions(game) {
  const { player, entities } = game;

  entities.forEach(entity => {
    if (entity.collected || !entity.active) return;
    if (entity.type === ENTITY_TYPES.HIDDEN_PEST && !entity.triggered) return;

    // AABB collision
    const collides =
      player.x < entity.x + entity.width &&
      player.x + player.width > entity.x &&
      player.y < entity.y + entity.height &&
      player.y + player.height > entity.y;

    if (!collides) return;

    switch (entity.type) {
      case ENTITY_TYPES.SEED:
        entity.collected = true;
        game.seeds++;
        break;

      case ENTITY_TYPES.FAKE_SEED:
        // TRAP! Looks like a seed but kills you
        killPlayer(game, "Essa semente era envenenada! ☠️");
        break;

      case ENTITY_TYPES.WATER:
        entity.collected = true;
        game.seeds += 3;
        break;

      case ENTITY_TYPES.PEST_WALK:
      case ENTITY_TYPES.HIDDEN_PEST:
        if (player.shieldTimer > 0) {
          // Shield kills the pest
          entity.active = false;
          entity.collected = true;
          game.seeds += 2;
        } else if (player.velocityY > 0 && player.y + player.height - entity.y < 16) {
          entity.active = false;
          entity.collected = true;
          player.velocityY = JUMP_FORCE * 0.7;
          game.seeds += 2;
        } else {
          killPlayer(game, game.level.deathMessages[Math.floor(Math.random() * game.level.deathMessages.length)]);
        }
        break;

      case ENTITY_TYPES.PEST_FLY:
        if (player.shieldTimer > 0) {
          entity.active = false;
          entity.collected = true;
          game.seeds += 3;
        } else if (player.velocityY > 0 && player.y + player.height - entity.y < 20) {
          entity.active = false;
          entity.collected = true;
          player.velocityY = JUMP_FORCE * 0.8;
          game.seeds += 3;
        } else {
          killPlayer(game, "A praga voadora te pegou! 🦟");
        }
        break;

      case ENTITY_TYPES.POLLUTION:
        if (player.shieldTimer > 0) break; // shield blocks pollution
        killPlayer(game, "A poluição é mortal! Agricultura limpa importa! ☁️");
        break;

      case ENTITY_TYPES.WEED:
        killPlayer(game, "As ervas invasoras te pegaram! 🌿");
        break;

      case ENTITY_TYPES.BOSS:
        if (entity.invincibleTimer > 0) break;
        // Stomp from above to damage boss
        if (player.velocityY > 0 && player.y + player.height - entity.y < 20) {
          entity.hp--;
          entity.invincibleTimer = 60;
          player.velocityY = JUMP_FORCE * 0.9;
          game.seeds += 5;
          if (entity.hp <= 0) {
            entity.active = false;
            entity.collected = true;
            game.seeds += 20;
          }
        } else {
          killPlayer(game, game.level.deathMessages[Math.floor(Math.random() * game.level.deathMessages.length)]);
        }
        break;

      case ENTITY_TYPES.POWER_UP:
        entity.collected = true;
        player.activePower = entity.powerType;
        player.powerCooldown = 0;
        game.seeds += 1;
        break;

      case ENTITY_TYPES.GOAL:
        // Only allow goal if boss is defeated (if level has a boss)
        if (game.level.hasBoss) {
          const boss = game.entities.find(e => e.type === ENTITY_TYPES.BOSS);
          if (boss && !boss.collected) break; // Boss must be defeated first
        }
        game.state = 'victory';
        break;
    }
  });
}

export function killPlayer(game, message) {
  if (game.player.isDead || game.state !== 'playing') return;
  game.player.isDead = true;
  game.player.velocityY = JUMP_FORCE;
  game.lives--;
  game.deathMessage = message;
  game.state = 'dead';
  game.deathTimer = 0;
}

export function respawnPlayer(game) {
  if (game.lives <= 0) {
    game.state = 'gameover';
    return game;
  }

  const newGame = createGameState(game.levelIndex);
  newGame.lives = game.lives;
  newGame.seeds = game.seeds;
  return newGame;
}

function firePower(game) {
  const { player } = game;
  if (!player.activePower) return;

  if (player.activePower === POWER_TYPES.LEAF_SHIELD) {
    // Leaf shield: instant AoE — no projectile, just timer
    player.shieldTimer = 180; // 3 seconds
    player.powerCooldown = 300; // 5s cooldown
    return;
  }

  // Projectile powers
  const speed = player.activePower === POWER_TYPES.WATER_JET ? 14 : 10;
  const piercing = player.activePower === POWER_TYPES.WATER_JET;
  game.projectiles.push({
    x: player.facingRight ? player.x + player.width : player.x - 12,
    y: player.y + player.height / 2 - 5,
    width: player.activePower === POWER_TYPES.WATER_JET ? 16 : 10,
    height: player.activePower === POWER_TYPES.WATER_JET ? 10 : 10,
    velocityX: player.facingRight ? speed : -speed,
    type: player.activePower,
    piercing,
    life: 60,
  });
  player.powerCooldown = player.activePower === POWER_TYPES.WATER_JET ? 25 : 18;
}

function updateProjectiles(game) {
  const { projectiles, entities, level } = game;

  for (let i = projectiles.length - 1; i >= 0; i--) {
    const p = projectiles[i];
    p.x += p.velocityX;
    p.life--;

    // Remove if off screen or expired
    if (p.life <= 0 || p.x < 0 || p.x > level.width * TILE_SIZE) {
      projectiles.splice(i, 1);
      continue;
    }

    // Tile collision
    const tileX = Math.floor((p.x + p.width / 2) / TILE_SIZE);
    const tileY = Math.floor((p.y + p.height / 2) / TILE_SIZE);
    const tile = level.tiles[tileY]?.[tileX] ?? 0;
    if (tile === TILES.GROUND || tile === TILES.GRASS_TOP) {
      projectiles.splice(i, 1);
      continue;
    }

    // Entity hit detection
    let hitSolid = false;
    for (const entity of entities) {
      if (entity.collected || !entity.active) continue;
      if (entity.type === ENTITY_TYPES.SEED || entity.type === ENTITY_TYPES.FAKE_SEED ||
          entity.type === ENTITY_TYPES.WATER || entity.type === ENTITY_TYPES.GOAL ||
          entity.type === ENTITY_TYPES.POWER_UP) continue;

      const hits =
        p.x < entity.x + entity.width &&
        p.x + p.width > entity.x &&
        p.y < entity.y + entity.height &&
        p.y + p.height > entity.y;

      if (hits) {
        if (entity.type === ENTITY_TYPES.BOSS) {
          if (entity.invincibleTimer <= 0) {
            entity.hp--;
            entity.invincibleTimer = 40;
            game.seeds += 3;
            if (entity.hp <= 0) {
              entity.active = false;
              entity.collected = true;
              game.seeds += 20;
            }
          }
        } else {
          entity.active = false;
          entity.collected = true;
          game.seeds += 2;
        }
        if (!p.piercing) { hitSolid = true; break; }
      }
    }
    if (hitSolid) { projectiles.splice(i, 1); }
  }
}

export function nextLevel(game) {
  const nextIndex = game.levelIndex + 1;
  const newGame = createGameState(nextIndex);
  if (!newGame) {
    // No more levels — total win
    game.state = 'gameclear';
    return game;
  }
  newGame.lives = game.lives;
  newGame.seeds = game.seeds;
  return newGame;
}