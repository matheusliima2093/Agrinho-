// Game constants
export const TILE_SIZE = 40;
export const GRAVITY = 0.6;
export const JUMP_FORCE = -12;
export const MOVE_SPEED = 4;
export const PLAYER_WIDTH = 32;
export const PLAYER_HEIGHT = 40;
export const CANVAS_WIDTH = 800;
export const CANVAS_HEIGHT = 480;

// Colors
export const COLORS = {
  sky: '#87CEEB',
  skyGradientTop: '#5BA3D9',
  skyGradientBottom: '#B8E4F0',
  grass: '#4A8C3F',
  grassLight: '#5DA84E',
  dirt: '#8B6914',
  dirtDark: '#6B4F10',
  farmerSkin: '#E8B87A',
  farmerHat: '#C4A535',
  farmerShirt: '#2E7D32',
  farmerPants: '#5D4037',
  farmerBoots: '#3E2723',
  pestGreen: '#6B8E23',
  pestRed: '#B22222',
  weed: '#556B2F',
  seed: '#FFD700',
  water: '#4FC3F7',
  corn: '#F9A825',
  tomato: '#E53935',
  carrot: '#FF6D00',
  flagPole: '#795548',
  flagGreen: '#2E7D32',
  cloud: '#FFFFFF',
  barn: '#8B0000',
  barnRoof: '#5C0000',
  fence: '#D2B48C',
  sunflower: '#FFC107',
  sunflowerCenter: '#5D4037',
  trapPlatform: '#4A8C3F',
  deathText: '#E53935',
  uiGreen: '#2E7D32',
  uiGold: '#FFD700',
};

// Tile types
export const TILES = {
  EMPTY: 0,
  GROUND: 1,
  GRASS_TOP: 2,
  PLATFORM: 3,
  FAKE_PLATFORM: 4, // Looks solid, but collapses
  HIDDEN_BLOCK: 5,
  SPIKE_UP: 6,
  CORN: 7,
  BARN_WALL: 8,
  BARN_ROOF: 9,
  FENCE: 10,
  FLAG: 11,
  SPRING_TRAP: 12, // Looks like a crop, launches player into death
  INVISIBLE_WALL: 13,
};

// Entity types
export const ENTITY_TYPES = {
  SEED: 'seed',
  WATER: 'water',
  PEST_WALK: 'pest_walk',
  PEST_FLY: 'pest_fly',
  WEED: 'weed',
  POLLUTION: 'pollution',
  FALLING_ROCK: 'falling_rock',
  FAKE_SEED: 'fake_seed',
  HIDDEN_PEST: 'hidden_pest',
  CHECKPOINT: 'checkpoint',
  GOAL: 'goal',
  BOSS: 'boss',
  POWER_UP: 'power_up', // Agrinho power-ups
};

// Power-up types
export const POWER_TYPES = {
  SEED_SHOT: 'seed_shot',     // 🌱 Semente Explosiva — shoots seeds forward
  WATER_JET: 'water_jet',     // 💧 Jato d'Água — piercing water projectile
  LEAF_SHIELD: 'leaf_shield', // 🌿 Escudo de Folhas — brief invincibility + stomps nearby pests
};