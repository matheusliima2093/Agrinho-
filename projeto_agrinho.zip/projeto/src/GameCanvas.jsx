import React, { useRef, useEffect, useCallback } from 'react';
import { CANVAS_WIDTH, CANVAS_HEIGHT, TILE_SIZE } from './constants';
import { createGameState, updateGame, respawnPlayer, nextLevel } from './engine';
import {
  drawBackground, drawTile, drawPlayer, drawEntity, drawProjectile,
  drawHUD, drawDeathScreen, drawVictoryScreen
} from './renderer';

export default function GameCanvas({ onStateChange }) {
  const canvasRef = useRef(null);
  const gameRef = useRef(null);
  const animRef = useRef(null);

  const initGame = useCallback(() => {
    gameRef.current = createGameState(0);
    if (onStateChange) onStateChange('playing');
  }, [onStateChange]);

  useEffect(() => {
    initGame();

    const handleKeyDown = (e) => {
      if (!gameRef.current) return;
      const game = gameRef.current;

      // Prevent scrolling
      if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space'].includes(e.code)) {
        e.preventDefault();
      }

      game.keys[e.code] = true;

      // Handle restart on space during dead/victory/gameover
      if (e.code === 'Space') {
        if (game.state === 'dead' && game.deathTimer > 30) {
          gameRef.current = respawnPlayer(game);
          if (onStateChange) onStateChange(gameRef.current.state);
        } else if (game.state === 'victory') {
          gameRef.current = nextLevel(game);
          if (onStateChange) onStateChange(gameRef.current.state);
        } else if (game.state === 'gameover' || game.state === 'gameclear') {
          gameRef.current = createGameState(0);
          if (onStateChange) onStateChange('playing');
        }
      }
    };

    const handleKeyUp = (e) => {
      if (!gameRef.current) return;
      gameRef.current.keys[e.code] = false;
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      if (animRef.current) cancelAnimationFrame(animRef.current);
    };
  }, [initGame, onStateChange]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');

    const gameLoop = () => {
      const game = gameRef.current;
      if (!game) {
        animRef.current = requestAnimationFrame(gameLoop);
        return;
      }

      // Update
      if (game.state === 'playing') {
        updateGame(game);
      } else if (game.state === 'dead') {
        game.deathTimer++;
        // Float the dead player
        game.player.velocityY += 0.3;
        game.player.y += game.player.velocityY;
      }

      // Render
      ctx.clearRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

      // Background
      drawBackground(ctx, game.camera.x);

      // Save and translate for camera
      ctx.save();
      ctx.translate(-game.camera.x, 0);

      // Draw tiles
      const startTile = Math.max(0, Math.floor(game.camera.x / TILE_SIZE) - 1);
      const endTile = Math.min(game.level.width, startTile + Math.ceil(CANVAS_WIDTH / TILE_SIZE) + 2);

      for (let y = 0; y < game.level.height; y++) {
        for (let x = startTile; x < endTile; x++) {
          const tile = game.level.tiles[y]?.[x];
          if (tile && tile !== 0) {
            drawTile(ctx, tile, x, y, game.frame);
          }
        }
      }

      // Draw entities
      game.entities.forEach(entity => {
        drawEntity(ctx, entity, game.frame);
      });

      // Draw projectiles
      game.projectiles.forEach(p => drawProjectile(ctx, p, game.frame));

      // Draw player
      drawPlayer(ctx, game.player, game.frame);

      ctx.restore();

      // Draw HUD
      const bossEntity = game.entities.find(e => e.type === 'boss' && e.active);
      drawHUD(ctx, game.lives, game.seeds, game.levelIndex + 1, bossEntity, game.player);

      // Draw overlays
      if (game.state === 'dead') {
        drawDeathScreen(ctx, game.deathMessage, game.deathTimer);
      } else if (game.state === 'victory') {
        drawVictoryScreen(ctx, game.seeds, game.frame, game.levelIndex);
      } else if (game.state === 'gameover') {
        drawGameOver(ctx, game.seeds, game.frame);
      } else if (game.state === 'gameclear') {
        drawGameClear(ctx, game.seeds, game.frame);
      }

      animRef.current = requestAnimationFrame(gameLoop);
    };

    animRef.current = requestAnimationFrame(gameLoop);
    return () => {
      if (animRef.current) cancelAnimationFrame(animRef.current);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      width={CANVAS_WIDTH}
      height={CANVAS_HEIGHT}
      className="block max-w-full rounded-xl shadow-2xl border-2 border-primary/20"
      style={{ imageRendering: 'pixelated', aspectRatio: `${CANVAS_WIDTH}/${CANVAS_HEIGHT}` }}
    />
  );
}

function drawGameClear(ctx, seeds, frame) {
  ctx.fillStyle = `rgba(0, 40, 0, ${Math.min(0.9, frame * 0.01)})`;
  ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

  ctx.fillStyle = '#FFD700';
  ctx.font = "bold 20px 'Press Start 2P', monospace";
  ctx.textAlign = 'center';
  ctx.fillText('🌾 VOCÊ SALVOU A FAZENDA! 🌾', CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2 - 60);

  ctx.fillStyle = '#90EE90';
  ctx.font = "13px 'Press Start 2P', monospace";
  ctx.fillText('Agricultura Forte,', CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2 - 20);
  ctx.fillText('Futuro Sustentavel!', CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2 + 8);

  ctx.fillStyle = '#FFF';
  ctx.font = "11px 'Press Start 2P', monospace";
  ctx.fillText(`Sementes: ${seeds}`, CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2 + 40);

  ctx.font = "9px 'Press Start 2P', monospace";
  ctx.fillText('ESPACO para jogar de novo', CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2 + 75);
  ctx.textAlign = 'left';
}

function drawGameOver(ctx, seeds, frame) {
  ctx.fillStyle = `rgba(0, 0, 0, ${Math.min(0.85, frame * 0.01)})`;
  ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

  ctx.fillStyle = '#E53935';
  ctx.font = "bold 24px 'Press Start 2P', monospace";
  ctx.textAlign = 'center';
  ctx.fillText('FIM DE JOGO', CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2 - 40);

  ctx.fillStyle = '#FFF';
  ctx.font = "12px 'Press Start 2P', monospace";
  ctx.fillText(`Sementes: ${seeds}`, CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2 + 10);
  ctx.fillText('A fazenda precisa de voce!', CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2 + 40);

  ctx.font = "10px 'Press Start 2P', monospace";
  ctx.fillText('ESPACO para tentar de novo', CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2 + 80);
  ctx.textAlign = 'left';
}