import { TILE_SIZE, TILES, COLORS, CANVAS_WIDTH, CANVAS_HEIGHT, POWER_TYPES } from './constants';

// Draw the scrolling background
export function drawBackground(ctx, cameraX) {
  const w = CANVAS_WIDTH;
  const h = CANVAS_HEIGHT;

  // Sky gradient
  const grad = ctx.createLinearGradient(0, 0, 0, h);
  grad.addColorStop(0, COLORS.skyGradientTop);
  grad.addColorStop(1, COLORS.skyGradientBottom);
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, w, h);

  // Sun
  const sunX = w - 80;
  const sunY = 60;
  ctx.fillStyle = '#FFF176';
  ctx.beginPath();
  ctx.arc(sunX, sunY, 35, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#FFEE58';
  ctx.beginPath();
  ctx.arc(sunX, sunY, 28, 0, Math.PI * 2);
  ctx.fill();

  // Parallax clouds
  drawClouds(ctx, cameraX);

  // Distant hills (parallax)
  drawHills(ctx, cameraX);
}

function drawClouds(ctx, cameraX) {
  ctx.fillStyle = 'rgba(255,255,255,0.8)';
  const clouds = [
    { x: 100, y: 40, w: 80, h: 25 },
    { x: 350, y: 60, w: 100, h: 30 },
    { x: 600, y: 30, w: 70, h: 22 },
    { x: 900, y: 50, w: 90, h: 28 },
    { x: 1200, y: 35, w: 85, h: 26 },
    { x: 1600, y: 55, w: 95, h: 30 },
    { x: 2000, y: 40, w: 75, h: 24 },
    { x: 2400, y: 65, w: 110, h: 32 },
  ];
  clouds.forEach(c => {
    const px = c.x - cameraX * 0.2;
    const wrapped = ((px % 2800) + 2800) % 2800 - 200;
    ctx.beginPath();
    ctx.ellipse(wrapped, c.y, c.w / 2, c.h / 2, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.ellipse(wrapped - c.w * 0.25, c.y + 5, c.w * 0.3, c.h * 0.4, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.ellipse(wrapped + c.w * 0.25, c.y + 3, c.w * 0.35, c.h * 0.45, 0, 0, Math.PI * 2);
    ctx.fill();
  });
}

function drawHills(ctx, cameraX) {
  // Far hills
  ctx.fillStyle = '#7CB342';
  ctx.beginPath();
  ctx.moveTo(0, CANVAS_HEIGHT);
  for (let x = 0; x <= CANVAS_WIDTH + 50; x += 5) {
    const worldX = x + cameraX * 0.3;
    const y = CANVAS_HEIGHT - 120 + Math.sin(worldX * 0.003) * 30 + Math.sin(worldX * 0.007) * 15;
    ctx.lineTo(x, y);
  }
  ctx.lineTo(CANVAS_WIDTH, CANVAS_HEIGHT);
  ctx.closePath();
  ctx.fill();

  // Near hills
  ctx.fillStyle = '#689F38';
  ctx.beginPath();
  ctx.moveTo(0, CANVAS_HEIGHT);
  for (let x = 0; x <= CANVAS_WIDTH + 50; x += 5) {
    const worldX = x + cameraX * 0.5;
    const y = CANVAS_HEIGHT - 80 + Math.sin(worldX * 0.005 + 2) * 20 + Math.sin(worldX * 0.01) * 10;
    ctx.lineTo(x, y);
  }
  ctx.lineTo(CANVAS_WIDTH, CANVAS_HEIGHT);
  ctx.closePath();
  ctx.fill();
}

// Draw a single tile
export function drawTile(ctx, type, x, y, frame) {
  const px = x * TILE_SIZE;
  const py = y * TILE_SIZE;

  switch (type) {
    case TILES.GROUND:
      ctx.fillStyle = COLORS.dirt;
      ctx.fillRect(px, py, TILE_SIZE, TILE_SIZE);
      ctx.fillStyle = COLORS.dirtDark;
      ctx.fillRect(px, py, TILE_SIZE, 2);
      // Dirt texture dots
      for (let i = 0; i < 3; i++) {
        ctx.fillStyle = COLORS.dirtDark;
        ctx.fillRect(px + 8 + i * 12, py + 10 + (i % 2) * 14, 3, 3);
      }
      break;

    case TILES.GRASS_TOP:
      // Dirt base
      ctx.fillStyle = COLORS.dirt;
      ctx.fillRect(px, py, TILE_SIZE, TILE_SIZE);
      // Grass top
      ctx.fillStyle = COLORS.grass;
      ctx.fillRect(px, py, TILE_SIZE, 14);
      ctx.fillStyle = COLORS.grassLight;
      ctx.fillRect(px, py, TILE_SIZE, 6);
      // Grass blades
      ctx.fillStyle = COLORS.grassLight;
      for (let i = 0; i < 5; i++) {
        ctx.fillRect(px + 2 + i * 8, py - 3, 3, 6);
      }
      break;

    case TILES.PLATFORM:
      // Wooden platform
      ctx.fillStyle = '#A0522D';
      ctx.fillRect(px, py, TILE_SIZE, TILE_SIZE / 2);
      ctx.fillStyle = '#8B4513';
      ctx.fillRect(px, py + TILE_SIZE / 2 - 2, TILE_SIZE, 2);
      ctx.fillStyle = '#CD853F';
      ctx.fillRect(px + 2, py + 2, TILE_SIZE - 4, 4);
      // Wood grain
      ctx.strokeStyle = '#8B4513';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(px + 10, py + 4);
      ctx.lineTo(px + 10, py + 16);
      ctx.moveTo(px + 25, py + 4);
      ctx.lineTo(px + 25, py + 16);
      ctx.stroke();
      break;

    case TILES.FAKE_PLATFORM:
      // Looks exactly like a regular platform
      ctx.fillStyle = '#A0522D';
      ctx.fillRect(px, py, TILE_SIZE, TILE_SIZE / 2);
      ctx.fillStyle = '#8B4513';
      ctx.fillRect(px, py + TILE_SIZE / 2 - 2, TILE_SIZE, 2);
      ctx.fillStyle = '#CD853F';
      ctx.fillRect(px + 2, py + 2, TILE_SIZE - 4, 4);
      ctx.strokeStyle = '#8B4513';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(px + 10, py + 4);
      ctx.lineTo(px + 10, py + 16);
      ctx.moveTo(px + 25, py + 4);
      ctx.lineTo(px + 25, py + 16);
      ctx.stroke();
      break;

    case TILES.SPIKE_UP:
      ctx.fillStyle = '#5D4037';
      for (let i = 0; i < 4; i++) {
        ctx.beginPath();
        ctx.moveTo(px + i * 10, py + TILE_SIZE);
        ctx.lineTo(px + i * 10 + 5, py + 8);
        ctx.lineTo(px + i * 10 + 10, py + TILE_SIZE);
        ctx.closePath();
        ctx.fill();
      }
      break;

    case TILES.CORN:
      // Corn stalk
      ctx.fillStyle = '#558B2F';
      ctx.fillRect(px + 17, py + 10, 6, TILE_SIZE - 10);
      // Corn ear
      ctx.fillStyle = COLORS.corn;
      ctx.fillRect(px + 12, py + 14, 16, 12);
      ctx.fillStyle = '#F57F17';
      for (let r = 0; r < 3; r++) {
        for (let c = 0; c < 4; c++) {
          ctx.fillRect(px + 13 + c * 4, py + 15 + r * 4, 3, 3);
        }
      }
      // Leaves
      ctx.fillStyle = '#33691E';
      ctx.beginPath();
      ctx.moveTo(px + 23, py + 16);
      ctx.lineTo(px + 36, py + 10);
      ctx.lineTo(px + 23, py + 22);
      ctx.fill();
      break;

    case TILES.FENCE:
      ctx.fillStyle = COLORS.fence;
      // Posts
      ctx.fillRect(px + 4, py, 6, TILE_SIZE);
      ctx.fillRect(px + 30, py, 6, TILE_SIZE);
      // Rails
      ctx.fillRect(px, py + 8, TILE_SIZE, 5);
      ctx.fillRect(px, py + 26, TILE_SIZE, 5);
      break;

    case TILES.FLAG:
      // Flag pole
      ctx.fillStyle = COLORS.flagPole;
      ctx.fillRect(px + 18, py, 4, TILE_SIZE);
      // Ball on top
      ctx.fillStyle = COLORS.uiGold;
      ctx.beginPath();
      ctx.arc(px + 20, py + 4, 5, 0, Math.PI * 2);
      ctx.fill();
      // Flag
      const wave = Math.sin(frame * 0.1) * 3;
      ctx.fillStyle = COLORS.flagGreen;
      ctx.beginPath();
      ctx.moveTo(px + 22, py + 6);
      ctx.lineTo(px + 38 + wave, py + 12);
      ctx.lineTo(px + 22, py + 22);
      ctx.closePath();
      ctx.fill();
      // "Agrinho" text hint
      ctx.fillStyle = '#FFF';
      ctx.font = '5px sans-serif';
      ctx.fillText('🌱', px + 25, py + 17);
      break;

    default:
      break;
  }
}

// Draw the farmer player
export function drawPlayer(ctx, player, frame) {
  const { x, y, width, height, facingRight, isDead, isJumping } = player;
  const bounce = isJumping ? 0 : Math.sin(frame * 0.3) * 2;

  ctx.save();
  if (!facingRight) {
    ctx.translate(x + width / 2, 0);
    ctx.scale(-1, 1);
    ctx.translate(-(x + width / 2), 0);
  }

  if (isDead) {
    // Death animation - farmer falls with X eyes
    ctx.globalAlpha = 0.8;
  }

  // Boots
  ctx.fillStyle = COLORS.farmerBoots;
  ctx.fillRect(x + 4, y + height - 8, 10, 8);
  ctx.fillRect(x + width - 14, y + height - 8, 10, 8);

  // Pants
  ctx.fillStyle = COLORS.farmerPants;
  ctx.fillRect(x + 4, y + height - 18, 10, 12);
  ctx.fillRect(x + width - 14, y + height - 18, 10, 12);

  // Body/shirt
  ctx.fillStyle = COLORS.farmerShirt;
  ctx.fillRect(x + 4, y + 12 + bounce, width - 8, 14);
  // Overalls straps
  ctx.fillStyle = '#1B5E20';
  ctx.fillRect(x + 6, y + 12 + bounce, 3, 14);
  ctx.fillRect(x + width - 9, y + 12 + bounce, 3, 14);

  // Arms
  const armSwing = isJumping ? -4 : Math.sin(frame * 0.3) * 5;
  // Left arm
  ctx.fillStyle = COLORS.farmerShirt;
  ctx.fillRect(x - 4, y + 13 + bounce + armSwing, 6, 10);
  ctx.fillStyle = COLORS.farmerSkin;
  ctx.fillRect(x - 4, y + 22 + bounce + armSwing, 6, 5); // hand
  // Right arm
  ctx.fillStyle = COLORS.farmerShirt;
  ctx.fillRect(x + width - 2, y + 13 + bounce - armSwing, 6, 10);
  ctx.fillStyle = COLORS.farmerSkin;
  ctx.fillRect(x + width - 2, y + 22 + bounce - armSwing, 6, 5); // hand

  // Head
  ctx.fillStyle = COLORS.farmerSkin;
  ctx.fillRect(x + 8, y + 2 + bounce, width - 16, 14);

  // Eyes
  if (isDead) {
    ctx.strokeStyle = '#E53935';
    ctx.lineWidth = 2;
    // X eyes
    ctx.beginPath();
    ctx.moveTo(x + 12, y + 6 + bounce);
    ctx.lineTo(x + 16, y + 10 + bounce);
    ctx.moveTo(x + 16, y + 6 + bounce);
    ctx.lineTo(x + 12, y + 10 + bounce);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(x + width - 16, y + 6 + bounce);
    ctx.lineTo(x + width - 12, y + 10 + bounce);
    ctx.moveTo(x + width - 12, y + 6 + bounce);
    ctx.lineTo(x + width - 16, y + 10 + bounce);
    ctx.stroke();
  } else {
    ctx.fillStyle = '#1B1B1B';
    ctx.fillRect(x + 13, y + 7 + bounce, 3, 3);
    ctx.fillRect(x + width - 16, y + 7 + bounce, 3, 3);
    // Smile
    ctx.fillRect(x + 12, y + 12 + bounce, 8, 2);
  }

  // Straw hat
  ctx.fillStyle = COLORS.farmerHat;
  // Hat brim
  ctx.fillRect(x + 2, y - 2 + bounce, width - 4, 6);
  // Hat top
  ctx.fillStyle = '#D4B545';
  ctx.fillRect(x + 8, y - 8 + bounce, width - 16, 8);
  // Hat band
  ctx.fillStyle = '#8D6E1F';
  ctx.fillRect(x + 8, y - 2 + bounce, width - 16, 3);

  ctx.restore();
}

// Draw entities (enemies, collectibles)
export function drawEntity(ctx, entity, frame) {
  const { type, x, y, active, collected, triggered } = entity;
  if (!active && type !== 'hidden_pest') return;
  if (collected) return;

  const px = x;
  const py = y;

  switch (type) {
    case 'seed':
      drawSeed(ctx, px, py, frame);
      break;
    case 'fake_seed':
      drawSeed(ctx, px, py, frame, true); // Purple poisoned seed
      break;
    case 'water':
      drawWaterDrop(ctx, px, py, frame);
      break;
    case 'pest_walk':
      drawPestWalker(ctx, px, py, frame, entity.facingRight);
      break;
    case 'pest_fly':
      drawPestFlyer(ctx, px, py, frame);
      break;
    case 'hidden_pest':
      if (triggered) drawPestWalker(ctx, px, py, frame, entity.facingRight);
      break;
    case 'pollution':
      drawPollution(ctx, px, py, frame);
      break;
    case 'weed':
      drawWeed(ctx, px, py, frame);
      break;
    case 'power_up':
      drawPowerUp(ctx, px, py, frame, entity.powerType);
      break;
    case 'goal':
      drawGoalFlag(ctx, px, py, frame);
      break;
    case 'boss':
      drawBoss(ctx, entity, frame);
      break;
    default:
      break;
  }
}

function drawSeed(ctx, x, y, frame, fake = false) {
  const bob = Math.sin(frame * 0.08) * 4;
  const glowColor = fake ? 'rgba(160, 0, 220, 0.35)' : 'rgba(255, 215, 0, 0.3)';
  const bodyColor = fake ? '#9C27B0' : COLORS.seed;
  const innerColor = fake ? '#CE93D8' : '#FFA000';
  const sproutColor = fake ? '#7B1FA2' : '#4CAF50';

  // Glow
  ctx.fillStyle = glowColor;
  ctx.beginPath();
  ctx.arc(x + 12, y + 12 + bob, 14, 0, Math.PI * 2);
  ctx.fill();
  // Seed body
  ctx.fillStyle = bodyColor;
  ctx.beginPath();
  ctx.ellipse(x + 12, y + 12 + bob, 8, 10, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = innerColor;
  ctx.beginPath();
  ctx.ellipse(x + 12, y + 12 + bob, 5, 7, 0, 0, Math.PI * 2);
  ctx.fill();
  // Sprout
  ctx.fillStyle = sproutColor;
  ctx.beginPath();
  ctx.moveTo(x + 12, y + 2 + bob);
  ctx.lineTo(x + 8, y - 4 + bob);
  ctx.lineTo(x + 14, y + 2 + bob);
  ctx.fill();
  // Skull on fake seed
  if (fake) {
    ctx.font = '10px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillStyle = 'rgba(255,255,255,0.9)';
    ctx.fillText('☠', x + 12, y + 15 + bob);
    ctx.textAlign = 'left';
  }
}

function drawWaterDrop(ctx, x, y, frame) {
  const bob = Math.sin(frame * 0.1) * 3;
  ctx.fillStyle = COLORS.water;
  ctx.beginPath();
  ctx.moveTo(x + 12, y + bob);
  ctx.quadraticCurveTo(x + 24, y + 16 + bob, x + 12, y + 24 + bob);
  ctx.quadraticCurveTo(x, y + 16 + bob, x + 12, y + bob);
  ctx.fill();
  // Highlight
  ctx.fillStyle = 'rgba(255,255,255,0.5)';
  ctx.beginPath();
  ctx.ellipse(x + 9, y + 12 + bob, 3, 5, -0.3, 0, Math.PI * 2);
  ctx.fill();
}

function drawPestWalker(ctx, x, y, frame, facingRight) {
  const legAnim = Math.sin(frame * 0.2) * 3;

  ctx.save();
  if (!facingRight) {
    ctx.translate(x + 16, 0);
    ctx.scale(-1, 1);
    ctx.translate(-(x + 16), 0);
  }

  // Body
  ctx.fillStyle = COLORS.pestGreen;
  ctx.beginPath();
  ctx.ellipse(x + 16, y + 18, 14, 10, 0, 0, Math.PI * 2);
  ctx.fill();

  // Legs
  ctx.strokeStyle = '#4E6B14';
  ctx.lineWidth = 2;
  for (let i = 0; i < 3; i++) {
    ctx.beginPath();
    ctx.moveTo(x + 6 + i * 10, y + 24);
    ctx.lineTo(x + 4 + i * 10, y + 32 + (i % 2 === 0 ? legAnim : -legAnim));
    ctx.stroke();
  }

  // Eyes (angry)
  ctx.fillStyle = '#FFF';
  ctx.beginPath();
  ctx.arc(x + 22, y + 14, 5, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = COLORS.pestRed;
  ctx.beginPath();
  ctx.arc(x + 23, y + 14, 3, 0, Math.PI * 2);
  ctx.fill();

  // Antennae
  ctx.strokeStyle = COLORS.pestGreen;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(x + 24, y + 10);
  ctx.quadraticCurveTo(x + 28, y + 2, x + 30, y + 4);
  ctx.moveTo(x + 20, y + 10);
  ctx.quadraticCurveTo(x + 22, y, x + 18, y + 2);
  ctx.stroke();

  // Pincers
  ctx.fillStyle = '#8B0000';
  ctx.beginPath();
  ctx.moveTo(x + 28, y + 20);
  ctx.lineTo(x + 34, y + 16);
  ctx.lineTo(x + 34, y + 24);
  ctx.closePath();
  ctx.fill();

  ctx.restore();
}

function drawPestFlyer(ctx, x, y, frame) {
  const hover = Math.sin(frame * 0.08) * 8;
  const wingFlap = Math.sin(frame * 0.3) * 10;

  // Wings
  ctx.fillStyle = 'rgba(200, 200, 255, 0.6)';
  ctx.beginPath();
  ctx.ellipse(x + 4, y + 10 + hover, 12, 6 + wingFlap / 2, -0.3, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.ellipse(x + 28, y + 10 + hover, 12, 6 + wingFlap / 2, 0.3, 0, Math.PI * 2);
  ctx.fill();

  // Body
  ctx.fillStyle = '#5C6BC0';
  ctx.beginPath();
  ctx.ellipse(x + 16, y + 18 + hover, 10, 8, 0, 0, Math.PI * 2);
  ctx.fill();

  // Stripes
  ctx.fillStyle = '#3949AB';
  ctx.fillRect(x + 8, y + 16 + hover, 16, 2);
  ctx.fillRect(x + 10, y + 20 + hover, 12, 2);

  // Eyes
  ctx.fillStyle = '#E53935';
  ctx.beginPath();
  ctx.arc(x + 12, y + 14 + hover, 3, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.arc(x + 20, y + 14 + hover, 3, 0, Math.PI * 2);
  ctx.fill();
}

function drawPollution(ctx, x, y, frame) {
  const drift = Math.sin(frame * 0.04) * 6;
  const pulse = Math.sin(frame * 0.06) * 4;

  ctx.fillStyle = 'rgba(100, 100, 100, 0.5)';
  ctx.beginPath();
  ctx.ellipse(x + 20 + drift, y + 16, 22 + pulse, 14 + pulse / 2, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = 'rgba(80, 80, 80, 0.4)';
  ctx.beginPath();
  ctx.ellipse(x + 12 + drift, y + 12, 14 + pulse / 2, 10, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.ellipse(x + 28 + drift, y + 20, 16, 10, 0, 0, Math.PI * 2);
  ctx.fill();

  // Skull icon
  ctx.fillStyle = 'rgba(200, 200, 200, 0.7)';
  ctx.font = '14px sans-serif';
  ctx.fillText('☠', x + 14 + drift, y + 22);
}

function drawWeed(ctx, x, y, frame) {
  const sway = Math.sin(frame * 0.06 + x) * 3;

  ctx.fillStyle = COLORS.weed;
  // Stem
  ctx.fillRect(x + 14 + sway / 2, y + 8, 4, 28);
  // Leaves
  ctx.beginPath();
  ctx.moveTo(x + 16 + sway, y + 12);
  ctx.lineTo(x + 4 + sway, y + 6);
  ctx.lineTo(x + 12 + sway, y + 16);
  ctx.fill();
  ctx.beginPath();
  ctx.moveTo(x + 18 + sway, y + 18);
  ctx.lineTo(x + 32 + sway, y + 12);
  ctx.lineTo(x + 22 + sway, y + 22);
  ctx.fill();
  // Thorns
  ctx.fillStyle = '#8B0000';
  ctx.fillRect(x + 10 + sway, y + 14, 3, 3);
  ctx.fillRect(x + 24 + sway, y + 20, 3, 3);
}

function drawBoss(ctx, entity, frame) {
  const { x, y, bossType, hp, maxHp, width, height, invincibleTimer } = entity;

  // Flash white when hit
  if (invincibleTimer > 0 && Math.floor(invincibleTimer / 5) % 2 === 0) {
    ctx.globalAlpha = 0.4;
  }

  if (bossType === 'locust') {
    // Giant locust - big green insect
    const hover = Math.sin(frame * 0.07) * 10;
    // Wings
    ctx.fillStyle = 'rgba(180, 220, 100, 0.7)';
    ctx.beginPath();
    ctx.ellipse(x + 16, y + 20 + hover, 28, 14, -0.4, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.ellipse(x + 48, y + 20 + hover, 28, 14, 0.4, 0, Math.PI * 2);
    ctx.fill();
    // Body
    ctx.fillStyle = '#4A7C10';
    ctx.beginPath();
    ctx.ellipse(x + 32, y + 36 + hover, 22, 16, 0, 0, Math.PI * 2);
    ctx.fill();
    // Head
    ctx.fillStyle = '#5A8C20';
    ctx.beginPath();
    ctx.ellipse(x + 50, y + 28 + hover, 14, 12, 0.3, 0, Math.PI * 2);
    ctx.fill();
    // Eyes
    ctx.fillStyle = '#FF0000';
    ctx.beginPath();
    ctx.arc(x + 56, y + 24 + hover, 5, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#000';
    ctx.beginPath();
    ctx.arc(x + 57, y + 24 + hover, 2, 0, Math.PI * 2);
    ctx.fill();
    // Legs
    ctx.strokeStyle = '#3A6C10';
    ctx.lineWidth = 3;
    for (let i = 0; i < 3; i++) {
      ctx.beginPath();
      ctx.moveTo(x + 20 + i * 10, y + 48 + hover);
      ctx.lineTo(x + 14 + i * 10, y + 62 + hover);
      ctx.stroke();
    }
    // HP indicator crown
    ctx.fillStyle = '#FFD700';
    ctx.font = 'bold 10px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('👑 CHEFE', x + 32, y - 8 + hover);
    ctx.textAlign = 'left';

  } else if (bossType === 'pollution_boss') {
    // Giant toxic cloud boss
    const drift = Math.sin(frame * 0.04) * 8;
    const pulse = Math.sin(frame * 0.06) * 6;
    ctx.fillStyle = 'rgba(60, 60, 80, 0.75)';
    ctx.beginPath();
    ctx.ellipse(x + 32 + drift, y + 28, 34 + pulse, 22 + pulse / 2, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = 'rgba(40, 40, 60, 0.65)';
    ctx.beginPath();
    ctx.ellipse(x + 16 + drift, y + 20, 20 + pulse / 2, 14, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.ellipse(x + 48 + drift, y + 34, 22, 14, 0, 0, Math.PI * 2);
    ctx.fill();
    // Angry face
    ctx.fillStyle = 'rgba(255,50,50,0.9)';
    ctx.beginPath();
    ctx.arc(x + 22 + drift, y + 22, 7, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.arc(x + 42 + drift, y + 22, 7, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#000';
    ctx.beginPath();
    ctx.arc(x + 23 + drift, y + 22, 3, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.arc(x + 43 + drift, y + 22, 3, 0, Math.PI * 2);
    ctx.fill();
    // Skull
    ctx.fillStyle = 'rgba(220,220,220,0.8)';
    ctx.font = '20px sans-serif';
    ctx.fillText('☠', x + 24 + drift, y + 44);
    ctx.font = 'bold 10px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('👑 CHEFE', x + 32, y - 8);
    ctx.textAlign = 'left';

  } else if (bossType === 'weed_king') {
    // Giant weed/plant boss
    const sway = Math.sin(frame * 0.05) * 6;
    // Main stem
    ctx.fillStyle = '#2D5A1B';
    ctx.fillRect(x + 28 + sway / 2, y + 10, 8, 54);
    // Crown of thorns
    ctx.fillStyle = '#1A3D0A';
    for (let i = 0; i < 5; i++) {
      ctx.beginPath();
      ctx.moveTo(x + 16 + i * 8 + sway, y + 10);
      ctx.lineTo(x + 20 + i * 8 + sway, y - 12);
      ctx.lineTo(x + 24 + i * 8 + sway, y + 10);
      ctx.fill();
    }
    // Big leaves
    ctx.fillStyle = '#3A7A20';
    ctx.beginPath();
    ctx.moveTo(x + 32 + sway, y + 20);
    ctx.quadraticCurveTo(x - 4 + sway, y + 10, x + 4 + sway, y + 32);
    ctx.quadraticCurveTo(x + 18 + sway, y + 28, x + 32 + sway, y + 20);
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(x + 32 + sway, y + 30);
    ctx.quadraticCurveTo(x + 70 + sway, y + 18, x + 60 + sway, y + 42);
    ctx.quadraticCurveTo(x + 44 + sway, y + 38, x + 32 + sway, y + 30);
    ctx.fill();
    // Angry face
    ctx.fillStyle = '#8B2222';
    ctx.beginPath();
    ctx.arc(x + 24 + sway, y + 40, 5, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.arc(x + 40 + sway, y + 40, 5, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#FF4444';
    ctx.fillRect(x + 22 + sway, y + 50, 20, 3);
    // Thorns on stem
    ctx.fillStyle = '#8B0000';
    ctx.fillRect(x + 20 + sway, y + 25, 6, 6);
    ctx.fillRect(x + 38 + sway, y + 38, 6, 6);
    ctx.font = 'bold 10px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillStyle = '#FFD700';
    ctx.fillText('👑 CHEFE FINAL', x + 32, y - 8 + sway);
    ctx.textAlign = 'left';
  }

  ctx.globalAlpha = 1;

  // Boss HP bar (above boss)
  const barW = 64;
  const barH = 8;
  const barX = x;
  const barY = y - 22;
  ctx.fillStyle = '#333';
  ctx.fillRect(barX, barY, barW, barH);
  const hpRatio = Math.max(0, hp / maxHp);
  const hpColor = hpRatio > 0.6 ? '#4CAF50' : hpRatio > 0.3 ? '#FFC107' : '#F44336';
  ctx.fillStyle = hpColor;
  ctx.fillRect(barX, barY, barW * hpRatio, barH);
  ctx.strokeStyle = '#FFF';
  ctx.lineWidth = 1;
  ctx.strokeRect(barX, barY, barW, barH);
}

function drawGoalFlag(ctx, x, y, frame) {
  // Tractor/barn at goal
  const wave = Math.sin(frame * 0.08) * 3;

  // Pole
  ctx.fillStyle = COLORS.flagPole;
  ctx.fillRect(x + 14, y - 40, 5, 80);

  // Ball
  ctx.fillStyle = COLORS.uiGold;
  ctx.beginPath();
  ctx.arc(x + 16, y - 42, 6, 0, Math.PI * 2);
  ctx.fill();

  // Flag
  ctx.fillStyle = COLORS.flagGreen;
  ctx.beginPath();
  ctx.moveTo(x + 19, y - 38);
  ctx.lineTo(x + 50 + wave, y - 30);
  ctx.lineTo(x + 19, y - 18);
  ctx.closePath();
  ctx.fill();

  // Text on flag
  ctx.fillStyle = '#FFF';
  ctx.font = 'bold 8px sans-serif';
  ctx.fillText('META', x + 23, y - 26);

  // Base
  ctx.fillStyle = '#5D4037';
  ctx.fillRect(x + 6, y + 32, 20, 8);
}

function drawPowerUp(ctx, x, y, frame, powerType) {
  const bob = Math.sin(frame * 0.1) * 4;
  const pulse = 1 + Math.sin(frame * 0.1) * 0.12;

  ctx.save();
  ctx.translate(x + 16, y + 16 + bob);
  ctx.scale(pulse, pulse);

  // Outer glow ring
  const colors = {
    [POWER_TYPES.SEED_SHOT]: '#66BB6A',
    [POWER_TYPES.WATER_JET]: '#29B6F6',
    [POWER_TYPES.LEAF_SHIELD]: '#8BC34A',
  };
  const c = colors[powerType] || '#FFD700';
  ctx.fillStyle = c + '44';
  ctx.beginPath();
  ctx.arc(0, 0, 18, 0, Math.PI * 2);
  ctx.fill();
  // Inner circle
  ctx.fillStyle = c;
  ctx.beginPath();
  ctx.arc(0, 0, 12, 0, Math.PI * 2);
  ctx.fill();
  // Icon
  ctx.font = '14px sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  const icons = {
    [POWER_TYPES.SEED_SHOT]: '🌱',
    [POWER_TYPES.WATER_JET]: '💧',
    [POWER_TYPES.LEAF_SHIELD]: '🌿',
  };
  ctx.fillText(icons[powerType] || '✨', 0, 1);
  ctx.textBaseline = 'alphabetic';
  ctx.textAlign = 'left';
  ctx.restore();
}

export function drawProjectile(ctx, p, frame) {
  if (p.type === POWER_TYPES.SEED_SHOT) {
    // Green bouncing seed bullet
    const spin = frame * 0.3;
    ctx.save();
    ctx.translate(p.x + p.width / 2, p.y + p.height / 2);
    ctx.rotate(spin);
    ctx.fillStyle = '#4CAF50';
    ctx.beginPath();
    ctx.ellipse(0, 0, 6, 5, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#81C784';
    ctx.beginPath();
    ctx.ellipse(-1, -1, 3, 3, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  } else if (p.type === POWER_TYPES.WATER_JET) {
    // Blue elongated water burst
    ctx.save();
    ctx.translate(p.x + p.width / 2, p.y + p.height / 2);
    // Trail
    ctx.fillStyle = 'rgba(41, 182, 246, 0.3)';
    ctx.fillRect(p.velocityX > 0 ? -20 : 4, -4, 20, 8);
    // Main drop
    ctx.fillStyle = '#29B6F6';
    ctx.beginPath();
    ctx.ellipse(0, 0, 9, 6, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,0.6)';
    ctx.beginPath();
    ctx.ellipse(-2, -2, 3, 2, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }
}

// Draw HUD
export function drawHUD(ctx, lives, seeds, level, bossEntity, player) {
  // Semi-transparent bar
  ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
  ctx.fillRect(0, 0, CANVAS_WIDTH, 44);

  // Lives
  ctx.fillStyle = '#FFF';
  ctx.font = "bold 14px 'Press Start 2P', monospace";
  ctx.fillText(`❤️ x${lives}`, 16, 28);

  // Seeds
  ctx.fillText(`🌱 x${seeds}`, 180, 28);

  // Level
  ctx.fillText(`Level ${level}`, CANVAS_WIDTH - 180, 28);

  // Active power display — agricultural theme
  if (player && player.activePower) {
    const powerInfo = {
      [POWER_TYPES.SEED_SHOT]:   { icon: '🌱', name: 'SEMENTE', color: '#66BB6A' },
      [POWER_TYPES.WATER_JET]:   { icon: '💧', name: 'IRRIGAR',  color: '#29B6F6' },
      [POWER_TYPES.LEAF_SHIELD]: { icon: '🌿', name: 'ESCUDO',   color: '#8BC34A' },
    };
    const info = powerInfo[player.activePower] || { icon: '✨', name: 'PODER', color: '#FFD700' };
    const px2 = CANVAS_WIDTH / 2 - 50;

    // Pill background
    ctx.fillStyle = player.shieldTimer > 0 ? 'rgba(139,195,74,0.5)' : 'rgba(0,0,0,0.45)';
    ctx.beginPath();
    ctx.roundRect(px2, 6, 102, 32, 8);
    ctx.fill();
    ctx.strokeStyle = info.color;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.roundRect(px2, 6, 102, 32, 8);
    ctx.stroke();

    // Icon
    ctx.font = '18px sans-serif';
    ctx.textAlign = 'left';
    ctx.fillText(info.icon, px2 + 6, 29);

    // Name
    ctx.fillStyle = info.color;
    ctx.font = "bold 7px 'Press Start 2P', monospace";
    ctx.fillText(info.name, px2 + 30, 20);

    // Hint
    ctx.fillStyle = '#CCC';
    ctx.font = "6px 'Press Start 2P', monospace";
    ctx.fillText('Z = USAR', px2 + 30, 33);

    // Shield timer bar
    if (player.shieldTimer > 0) {
      ctx.fillStyle = '#8BC34A';
      ctx.fillRect(px2, 38, (player.shieldTimer / 180) * 102, 4);
    }

    // Cooldown dim overlay
    if (player.powerCooldown > 0 && player.shieldTimer <= 0) {
      ctx.fillStyle = 'rgba(0,0,0,0.4)';
      ctx.beginPath();
      ctx.roundRect(px2, 6, 102, 32, 8);
      ctx.fill();
    }
  }

  // Boss HP bar in HUD
  if (bossEntity && bossEntity.active) {
    const bossName = bossEntity.bossType === 'locust' ? 'GAFANHOTO GIGANTE'
      : bossEntity.bossType === 'pollution_boss' ? 'MONSTRO DA POLUIÇÃO'
      : 'REI DAS ERVAS';
    const barW = 200;
    const barX = CANVAS_WIDTH / 2 - barW / 2;
    const barY = 8;
    ctx.fillStyle = '#333';
    ctx.fillRect(barX, barY, barW, 14);
    const hpRatio = Math.max(0, bossEntity.hp / bossEntity.maxHp);
    const hpColor = hpRatio > 0.6 ? '#4CAF50' : hpRatio > 0.3 ? '#FFC107' : '#F44336';
    ctx.fillStyle = hpColor;
    ctx.fillRect(barX, barY, barW * hpRatio, 14);
    ctx.strokeStyle = '#FFD700';
    ctx.lineWidth = 2;
    ctx.strokeRect(barX, barY, barW, 14);
    ctx.fillStyle = '#FFF';
    ctx.font = "bold 8px 'Press Start 2P', monospace";
    ctx.textAlign = 'center';
    ctx.fillText(`👑 ${bossName}`, CANVAS_WIDTH / 2, barY + 11);
    ctx.textAlign = 'left';
  }
}

// Draw death screen overlay
export function drawDeathScreen(ctx, message, frame) {
  ctx.fillStyle = `rgba(0, 0, 0, ${Math.min(0.7, frame * 0.02)})`;
  ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

  ctx.fillStyle = COLORS.deathText;
  ctx.font = "bold 20px 'Press Start 2P', monospace";
  ctx.textAlign = 'center';
  ctx.fillText(message, CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2 - 20);

  ctx.fillStyle = '#FFF';
  ctx.font = "12px 'Press Start 2P', monospace";
  ctx.fillText('Pressione ESPAÇO para tentar novamente', CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2 + 30);
  ctx.textAlign = 'left';
}

// Draw victory screen
export function drawVictoryScreen(ctx, seeds, frame, levelIndex) {
  ctx.fillStyle = `rgba(0, 80, 0, ${Math.min(0.8, frame * 0.02)})`;
  ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

  ctx.fillStyle = COLORS.uiGold;
  ctx.font = "bold 22px 'Press Start 2P', monospace";
  ctx.textAlign = 'center';
  ctx.fillText('🌾 FASE CONCLUÍDA! 🌾', CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2 - 40);

  ctx.fillStyle = '#FFF';
  ctx.font = "12px 'Press Start 2P', monospace";
  ctx.fillText(`Sementes: ${seeds}`, CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2 + 10);

  ctx.font = "10px 'Press Start 2P', monospace";
  ctx.fillText('ESPAÇO para próxima fase!', CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2 + 50);
  ctx.textAlign = 'left';
}