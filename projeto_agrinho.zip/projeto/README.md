# 🌾 Agrinho — Jogo de Plataforma

Jogo 2D de plataforma desenvolvido com **React + Vite** para o concurso Agrinho.

## 🎮 Como jogar

| Tecla | Ação |
|-------|------|
| ← / → ou A / D | Mover |
| Espaço / ↑ / W | Pular |
| Z / Shift | Usar poder |

Em mobile, use os botões na tela.

---

## 🚀 Rodar localmente

```bash
# 1. Instalar dependências
npm install

# 2. Iniciar servidor de desenvolvimento
npm run dev
```

Acesse `http://localhost:5173` no navegador.

## 🏗️ Build para produção

```bash
npm run build
```

---

## 📁 Estrutura do projeto

```
src/
├── pages/
│   └── Game.jsx          # Página principal
├── components/
│   ├── ScrollToTop.jsx
│   ├── MobileControls.jsx
│   └── ...
├── lib/
│   ├── AuthContext.jsx
│   ├── query-client.js
│   └── ...
├── engine.jsx            # Lógica do jogo
├── renderer.jsx          # Renderização canvas
├── levels.jsx            # Dados dos níveis
├── constants.jsx         # Constantes do jogo
└── GameCanvas.jsx        # Componente canvas
```

## 📤 Subir no GitHub

```bash
git init
git add .
git commit -m "primeiro commit"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/SEU_REPOSITORIO.git
git push -u origin main
```
